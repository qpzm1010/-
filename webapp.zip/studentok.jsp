<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ include file="db.jsp" %>

<% request.setCharacterEncoding("UTF-8"); %>

<% 

try {
	String syear = request.getParameter("syear");
	String sclass = request.getParameter("sclass");
	String sno = request.getParameter("sno");
	String sname = request.getParameter("sname");
	String birth = request.getParameter("birth");
	String gender = request.getParameter("gender");
	String tel1 = request.getParameter("tel1");
	String tel2 = request.getParameter("tel2");
	String tel3 = request.getParameter("tel3");
	
	String sql = "INSERT INTO tbl_student_201905 VALUES (?,?,?,?,?,?,?,?,?)";
	
	PreparedStatement pstmt = con.prepareStatement(sql);
	
	pstmt.setString(1, syear);
	pstmt.setString(2, sclass);
	pstmt.setString(3, sno);
	pstmt.setString(4, sname);
	pstmt.setString(5, birth);
	pstmt.setString(6, gender);
	pstmt.setString(7, tel1);
	pstmt.setString(8, tel2);
	pstmt.setString(9, tel3);
	
	pstmt.executeUpdate();
}

catch (Exception e) {
	e.printStackTrace();
}

response.sendRedirect("student.jsp");



%>