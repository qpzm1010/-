<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ include file="db.jsp" %>
<% request.setCharacterEncoding("UTF-8"); %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>대학조회</title>
</head>
<body>

<style>

td {
	text-align: center;
}

tr {
	text-align: center;
}

table {
	margin: auto;
	text-align: center;
}

</style>

<jsp:include page="header.jsp"></jsp:include>

<section>

<h1 style="text-align: center;">대학조회</h1>

<table border=1 style="margin: auto; text-align: center; width: 60%;">
	<tr>
		<td>학교코드</td>
		<td>학교명</td>
		<td>전화번호</td>
	</tr>
	
	<%
	
	try {
		String sql = "SELECT university_code, university_name, phone_num FROM tbl_university ORDER BY university_code";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		
		while (rs.next()) {
			String university_code = rs.getString("university_code");
			String university_name = rs.getString("university_name");
			String phone_num = rs.getString("phone_num");
			
			String formatted_phone = "";
			if (phone_num != null && phone_num.length() == 11) {
				formatted_phone = phone_num.substring(0, 3) + "-" + phone_num.substring(3, 7) + "-" + phone_num.substring(7);
			} else {
				formatted_phone = phone_num;
			}
		
	%>
	
	<tr>
		<td><%=university_code %></td>
		<td><%=university_name %></td>
		<td><%=formatted_phone %></td>
	</tr>
		
	
	<% 
	
	}
	rs.close();
	pstmt.close();
	}

	catch (Exception e) {
		e.printStackTrace();
	}

	
	%>
</table>

</section>

<jsp:include page="footer.jsp"></jsp:include>

</body>
</html>
