<%@page import="java.text.DecimalFormat"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ include file="db.jsp" %>
<% request.setCharacterEncoding("UTF-8"); %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>원서접수조회</title>
</head>
<body>

<style>

tr {
	text-align: center;
}

table {
	margin: auto;
	text-align: center;
}

</style>

<jsp:include page="header.jsp"></jsp:include>

<section>

<h1 style="text-align: center;">원서접수조회</h1>

<table border=1 style="margin: auto; text-align: center; width: 80%;">
	<tr>
		<td>이름</td>
		<td>주민번호</td>
		<td>학교</td>
		<td>학과</td>
		<td>수능점수</td>
		<td>내신점수</td>
		<td>총점</td>
		<td>순위</td>
	</tr>
	
	<%
	
	try {
		String sql = "SELECT a.regist_num, a.name, u.university_name, m.major_name, " +
					"a.s_score, a.n_score, a.total_score, " +
					"ROW_NUMBER() OVER (ORDER BY a.total_score DESC, a.s_score DESC) AS ranking " +
					"FROM tbl_apply a " +
					"JOIN tbl_university u ON a.university_code = u.university_code " +
					"JOIN tbl_major m ON a.major_code = m.major_code " +
					"ORDER BY a.total_score DESC, a.s_score DESC";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		
		while (rs.next()) {
			String regist_num = rs.getString("regist_num");
			String name = rs.getString("name");
			String university_name = rs.getString("university_name");
			String major_name = rs.getString("major_name");
			int s_score = rs.getInt("s_score");
			int n_score = rs.getInt("n_score");
			int total_score = rs.getInt("total_score");
			int ranking = rs.getInt("ranking");
			
			String formatted_regist = "";
			if (regist_num != null && regist_num.length() == 13) {
				formatted_regist = regist_num.substring(0, 6) + "-" + regist_num.substring(6, 13);
			} else {
				formatted_regist = regist_num;
			}
		
	%>
	
	<tr>
		<td><%=name %></td>
		<td><%=formatted_regist %></td>
		<td><%=university_name %></td>
		<td><%=major_name %></td>
		<td style="text-align: right;"><%=s_score %></td>
		<td style="text-align: right;"><%=n_score %></td>
		<td style="text-align: right;"><%=total_score %></td>
		<td><%=ranking %></td>
	</tr>
		
	
	<% 
	
	}
	rs.close();
	pstmt.close();
	}

	catch (Exception e) {
		e.printStackTrace();
	}

	
	%>
</table>

</section>

<jsp:include page="footer.jsp"></jsp:include>

</body>
</html>
