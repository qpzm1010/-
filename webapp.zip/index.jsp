<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>대학 원서 접수 관리 프로그램</title>
</head>
<body>

<jsp:include page="header.jsp"></jsp:include>

<section>

<h1 style="text-align: center;">대학원서접수관리 프로그램</h1>

<p>본 과제는 대학별 원서접수 정보를 제공하는 관리 프로그램이다.</p>

</section>

<jsp:include page="footer.jsp"></jsp:include>

</body>
</html>
