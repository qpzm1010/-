<%@page import="java.text.DecimalFormat"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ include file="db.jsp" %>
<% request.setCharacterEncoding("UTF-8"); %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>원서등록</title>
</head>
<body>

<style>

td {
	text-align: center;
}

tr {
	text-align: center;
}

table {
	margin: auto;
	text-align: center;
}

</style>

<jsp:include page="header.jsp"></jsp:include>

<section>

<h1 style="text-align: center;">원서등록</h1>

<table border=1 style="margin: auto; text-align: center; width: 60%;">
	<tr>
		<td>학교코드</td>
		<td>학교명</td>
		<td>지원 인원</td>
		<td>총점 평균</td>
	</tr>
	
	<%
	try {
		String sql = "SELECT u.university_code, u.university_name, " +
					"COUNT(a.regist_num) AS apply_count, " +
					"NVL(AVG(a.total_score), 0) AS avg_score " +
					"FROM tbl_university u " +
					"LEFT JOIN tbl_apply a ON u.university_code = a.university_code " +
					"GROUP BY u.university_code, u.university_name " +
					"ORDER BY avg_score DESC, apply_count DESC";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		DecimalFormat df = new DecimalFormat("#.0");
		
		while (rs.next()) {
			String university_code = rs.getString("university_code");
			String university_name = rs.getString("university_name");
			int apply_count = rs.getInt("apply_count");
			double avg_score = rs.getDouble("avg_score");
	%>
	
	<tr>
		<td><%=university_code%></td>
		<td><%=university_name%></td>
		<td><%=apply_count%></td>
		<td><%=df.format(avg_score)%></td>
	</tr>
		
	<% 
	}
	rs.close();
	pstmt.close();
	}
	catch (Exception e) {
		e.printStackTrace();
	} 
	
	%>
</table>

</section>

<jsp:include page="footer.jsp"></jsp:include>

</body>
</html>
