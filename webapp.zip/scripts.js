function MemberCheck() {
	if (document.frm.syear.value == "") {
		alert("학년이 입력되지 않았습니다!");
		document.frm.syear.focus();
		return false
	}
	if (document.frm.sclass.value == "") {
		alert("반이 입력되지 않았습니다!");
		document.frm.sclass.focus();
		return false
	}
	if (document.frm.sno.value == "") {
		alert("번호가 입력되지 않았습니다!");
		document.frm.sno.focus();
		return false
	}
	if (document.frm.sname.value == "") {
		alert("이름이 입력되지 않았습니다!");
		document.frm.sname.focus();
		return false
	}
	if (document.frm.birth.value == "") {
		alert("생년월일이 입력되지 않았습니다!");
		document.frm.birth.focus();
		return false
	}
	if (!document.frm.gender.value[0] & !document.frm.gender.value[1]) {
		alert("생년월일이 입력되지 않았습니다!");
		document.frm.birth.focus();
		return false
	}
	if (document.frm.tel1.value == "") {
		alert("전화번호가 입력되지 않았습니다!");
		document.frm.tel1.focus();
		return false
	}
	if (document.frm.tel2.value == "") {
		alert("전화번호가 입력되지 않았습니다!");
		document.frm.tel2.focus();
		return false
	}
	if (document.frm.tel3.value == "") {
		alert("전화번호가 입력되지 않았습니다!");
		document.frm.tel3.focus();
		return false
	}
	alert("작성이 완료되었습니다!");
	return true
}

function ScoreCheck() {
	if (document.frm.syear.value == "") {
		alert("학년이 입력되지 않았습니다!");
		document.frm.syear.focus();
		return false
	}
	if (document.frm.sclass.value == "") {
		alert("반이 입력되지 않았습니다!");
		document.frm.sclass.focus();
		return false
	}
	if (document.frm.sno.value == "") {
		alert("번호가 입력되지 않았습니다!");
		document.frm.sno.focus();
		return false
	}
	if (document.frm.kor.value == "") {
		alert("국어점수가 입력되지 않았습니다!");
		document.frm.kor.focus();
		return false
	}
	if (document.frm.eng.value == "") {
		alert("영어점수가 입력되지 않았습니다!");
		document.frm.eng.focus();
		return false
	}
	if (document.frm.mat.value == "") {
		alert("수학점수가 입력되지 않았습니다!");
		document.frm.mat.focus();
		return false
	}
	alert("작성이 완료되었습니다!");
	return true
}

function Scorereset(){
	alert("정보를 지우고 처음부터 다시 입력합니다!")
}

function DriveCheck() {
	if (document.frm.drv_date.value == "") {
		alert("주행일자가 입력되지 않았습니다!");
		document.frm.drv_date.focus();
		return false
	}
	if (document.frm.car_no.value == "") {
		alert("차량번호가 입력되지 않았습니다!");
		document.frm.car_no.focus();
		return false
	}
	if (document.frm.drv_start.value == "") {
		alert("출발Km가 입력되지 않았습니다!");
		document.frm.drv_start.focus();
		return false
	}
	if (document.frm.drv_end.value == "") {
		alert("도착Km가 입력되지 않았습니다!");
		document.frm.drv_end.focus();
		return false
	}
	if (document.frm.dept_code.value == "") {
		alert("부서코드가 선택되지 않았습니다!");
		document.frm.dept_code.focus();
		return false
	}
	if (document.frm.drv_money.value == "") {
		alert("주유금액이 입력되지 않았습니다!");
		document.frm.drv_money.focus();
		return false
	}
	alert("작성이 완료되었습니다!");
	return true
}

function ApplyCheck() {
	if (document.frm.regist_num.value == "") {
		alert("주민번호가 입력되지 않았습니다!");
		document.frm.regist_num.focus();
		return false
	}
	if (document.frm.name.value == "") {
		alert("이름이 입력되지 않았습니다!");
		document.frm.name.focus();
		return false
	}
	if (document.frm.university_code.value == "") {
		alert("학교가 선택되지 않았습니다!");
		document.frm.university_code.focus();
		return false
	}
	if (document.frm.major_code.value == "") {
		alert("학과가 선택되지 않았습니다!");
		document.frm.major_code.focus();
		return false
	}
	if (document.frm.s_score.value == "") {
		alert("수능 점수가 입력되지 않았습니다!");
		document.frm.s_score.focus();
		return false
	}
	if (document.frm.n_score.value == "") {
		alert("내신 점수가 입력되지 않았습니다!");
		document.frm.n_score.focus();
		return false
	}
	var s_score = parseInt(document.frm.s_score.value);
	var n_score = parseInt(document.frm.n_score.value);
	if (isNaN(s_score) || s_score < 0 || s_score > 100) {
		alert("수능 점수는 0~100 범위로 입력해주세요!");
		document.frm.s_score.focus();
		return false
	}
	if (isNaN(n_score) || n_score < 0 || n_score > 100) {
		alert("내신 점수는 0~100 범위로 입력해주세요!");
		document.frm.n_score.focus();
		return false
	}
	return true
}

function ApplyReset() {
	document.frm.regist_num.focus();
}