<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ include file="db.jsp" %>

<% request.setCharacterEncoding("UTF-8"); %>

<% 

try {
	String regist_num = request.getParameter("regist_num");
	String name = request.getParameter("name");
	String university_code = request.getParameter("university_code");
	String major_code = request.getParameter("major_code");
	String s_score_str = request.getParameter("s_score");
	String n_score_str = request.getParameter("n_score");
	
	if (regist_num == null || regist_num.trim().equals("")) {
		%>
		<script>
		alert("주민번호가 입력되지 않았습니다!");
		history.back();
		</script>
		<%
		return;
	}
	
	if (name == null || name.trim().equals("")) {
		%>
		<script>
		alert("이름이 입력되지 않았습니다!");
		history.back();
		</script>
		<%
		return;
	}
	
	if (university_code == null || university_code.trim().equals("")) {
		%>
		<script>
		alert("학교가 선택되지 않았습니다!");
		history.back();
		</script>
		<%
		return;
	}
	
	if (major_code == null || major_code.trim().equals("")) {
		%>
		<script>
		alert("학과가 선택되지 않았습니다!");
		history.back();
		</script>
		<%
		return;
	}
	
	if (s_score_str == null || s_score_str.trim().equals("")) {
		%>
		<script>
		alert("수능 점수가 입력되지 않았습니다!");
		history.back();
		</script>
		<%
		return;
	}
	
	if (n_score_str == null || n_score_str.trim().equals("")) {
		%>
		<script>
		alert("내신 점수가 입력되지 않았습니다!");
		history.back();
		</script>
		<%
		return;
	}
	
	int s_score = Integer.parseInt(s_score_str);
	int n_score = Integer.parseInt(n_score_str);
	
	if (s_score < 0 || s_score > 100 || n_score < 0 || n_score > 100) {
		%>
		<script>
		alert("입력하신 데이터가 잘못되었습니다.");
		history.back();
		</script>
		<%
		return;
	}
	
	String checkSql = "SELECT regist_num FROM tbl_apply WHERE regist_num = ?";
	PreparedStatement checkPstmt = con.prepareStatement(checkSql);
	checkPstmt.setString(1, regist_num);
	ResultSet checkRs = checkPstmt.executeQuery();
	
	if (checkRs.next()) {
		checkRs.close();
		checkPstmt.close();
		%>
		<script>
		alert("이미 등록된 데이터입니다.");
		history.back();
		</script>
		<%
		return;
	}
	checkRs.close();
	checkPstmt.close();
	
	int total_score = s_score + n_score;
	
	String sql = "INSERT INTO tbl_apply (regist_num, university_code, major_code, name, s_score, n_score, total_score) VALUES (?, ?, ?, ?, ?, ?, ?)";
	
	PreparedStatement pstmt = con.prepareStatement(sql);
	
	pstmt.setString(1, regist_num);
	pstmt.setString(2, university_code);
	pstmt.setString(3, major_code);
	pstmt.setString(4, name);
	pstmt.setInt(5, s_score);
	pstmt.setInt(6, n_score);
	pstmt.setInt(7, total_score);
	
	pstmt.executeUpdate();
	
	pstmt.close();
	
	response.sendRedirect("score.jsp");
}
catch (NumberFormatException e) {
	%>
	<script>
	alert("입력하신 데이터가 잘못되었습니다.");
	history.back();
	</script>
	<%
}
catch (Exception e) {
	e.printStackTrace();
	%>
	<script>
	alert("입력하신 데이터가 잘못되었습니다.");
	history.back();
	</script>
	<%
}

%>
