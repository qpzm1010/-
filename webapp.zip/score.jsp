<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ include file="db.jsp" %>
<% request.setCharacterEncoding("UTF-8"); %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>원서등록</title>
</head>
<body>

<script type="text/javascript" src="scripts.js"></script>

<style>

td {
	text-align: center;
}

table {
	margin: auto;
	text-align: center;
}

</style>

<jsp:include page="header.jsp"></jsp:include>

<section>

<h1 style="text-align: center;">원서 등록</h1>

<form name="frm" method="post" action="scoreok.jsp">

	<table border=1 style="margin: auto; text-align: center;">
		<tr>
			<td style="text-align: center">주민번호</td>
			<td style="text-align: left;"><input type="text" name="regist_num" maxlength="13">예)0211113000011</td>
		</tr>
		<tr>
			<td style="text-align: center">이름</td>
			<td style="text-align: left;"><input type="text" name="name"></td>
		</tr>
		<tr>
			<td style="text-align: center">학교</td>
			<td style="text-align: left;">
				<select name="university_code">
					<option value="">학교</option>
					<%
					try {
						String sql = "SELECT university_code, university_name FROM tbl_university ORDER BY university_code";
						PreparedStatement pstmt = con.prepareStatement(sql);
						ResultSet rs = pstmt.executeQuery();
						
						while (rs.next()) {
							String university_code = rs.getString("university_code");
							String university_name = rs.getString("university_name");
					%>
					<option value="<%=university_code%>">[<%=university_code%>]<%=university_name%></option>
					<%
						}
						rs.close();
						pstmt.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
					%>
				</select>
			</td>
		</tr>
		<tr>
			<td style="text-align: center">학과</td>
			<td style="text-align: left;">
				<select name="major_code">
					<option value="">학과</option>
					<%
					try {
						String sql = "SELECT major_code, dept_name, major_name FROM tbl_major ORDER BY major_code";
						PreparedStatement pstmt = con.prepareStatement(sql);
						ResultSet rs = pstmt.executeQuery();
						
						while (rs.next()) {
							String major_code = rs.getString("major_code");
							String dept_name = rs.getString("dept_name");
							String major_name = rs.getString("major_name");
					%>
					<option value="<%=major_code%>">[<%=major_code%>]<%=dept_name%> → <%=major_name%></option>
					<%
						}
						rs.close();
						pstmt.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
					%>
				</select>
			</td>
		</tr>
		<tr>
			<td style="text-align: center">수능점수</td>
			<td style="text-align: left;"><input type="text" name="s_score">0~100</td>
		</tr>
		<tr>
			<td style="text-align: center">내신점수</td>
			<td style="text-align: left;"><input type="text" name="n_score">0~100</td>
		</tr>
		<tr>
			<td colspan="2" style="text-align: center;">
				<input type="submit" value="등록" onclick="return ApplyCheck()">
				<input type="reset" value="다시쓰기" onclick="ApplyReset()">
			</td>
		</tr>
	</table>

</form>

</section>

<jsp:include page="footer.jsp"></jsp:include>

</body>
</html>
