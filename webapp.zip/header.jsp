<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<header style="background-color: skyblue;">

<h1 style="text-align: center;">
	대학 원서 접수 관리 프로그램 Ver1.0
</h1>

<nav style="background-color: red;">

	<h3 style="text-align: left;">
	&emsp;
		<a href="student.jsp">대학조회</a> &emsp;&emsp;
		<a href="score.jsp">원서등록</a> &emsp;&emsp;
		<a href="score_list.jsp">원서접수조회</a> &emsp;&emsp;
		<a href="class.jsp">학교별통계</a> &emsp;&emsp;
		<a href="index.jsp">홈으로</a>
	
	</h3>

</nav>

</header>

</body>
</html>
