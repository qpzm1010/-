<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<style>

h3 {
text-align: center;
}

footer {

background-color: skyblue;
width: 100%;
bottom: 0;
position: fixed;

}


</style>

<footer>

	<h3>HRDKOREA Copyrightⓒ2025 All rights reserved. Human Resources Development Service of Korea</h3>

</footer>

</body>
</html>